#!/usr/bin/env python3
"""Validate Ventilation firmware, or explicitly install it through LAN Recovery.

Without --install this command reads local files only. Run it on a computer on
the ESP8266's LAN; it does not use MQTT or change Wi-Fi/MQTT credentials.
"""
from __future__ import annotations

import argparse
import hashlib
import html
import ipaddress
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request

PROJECT = Path(__file__).resolve().parents[1]
UPLOADER = Path(__file__).resolve().parent / 'vendor/espota.py'
UPLOADER_SHA256 = '08e7c1c10d55756463f13d694567959bc9b2acb7ffd174ed0f0804d315593691'


class OtaError(Exception):
    pass


def verify_firmware(metadata_path, image_path=None):
    metadata_path = Path(metadata_path)
    metadata = json.loads(metadata_path.read_text(encoding='utf-8'))
    if (metadata.get('application') != 'ventilation' or metadata.get('firmware') != '2.01'
            or metadata.get('oled') != 'NONE'
            or metadata.get('profile') != 'ventilation-3ds18b20-2dht11-none'):
        raise OtaError('Metadata is not the expected Ventilation 2.01 no-OLED profile')
    filename = metadata.get('filename', '')
    if Path(filename).name != filename or not filename.endswith('.bin'):
        raise OtaError('Invalid firmware filename in metadata')
    image_path = Path(image_path) if image_path else metadata_path.parent / filename
    image = image_path.read_bytes()
    if not image or image[0] != 0xE9 or len(image) != metadata.get('size'):
        raise OtaError('Firmware size or ESP8266 image header does not match')
    if hashlib.sha256(image).hexdigest() != metadata.get('sha256'):
        raise OtaError('Firmware SHA256 does not match; no device was contacted')
    if hashlib.sha256(UPLOADER.read_bytes()).hexdigest() != UPLOADER_SHA256:
        raise OtaError('Bundled espota.py differs from the validated upstream copy')
    return metadata, image


def private_ipv4(value):
    try:
        address = ipaddress.ip_address(value)
    except ValueError as error:
        raise OtaError('Use a private IPv4 LAN address') from error
    if address.version != 4 or not address.is_private or address.is_unspecified:
        raise OtaError('Use a private IPv4 LAN address')
    return str(address)


def request_text(ip, path, payload=None, timeout=5):
    # LAN requests must not be sent through an HTTP proxy configured on the PC.
    class NoRedirect(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None
    opener = urllib.request.build_opener(urllib.request.ProxyHandler({}), NoRedirect())
    data = urllib.parse.urlencode(payload).encode() if payload is not None else None
    request = urllib.request.Request('http://' + ip + path, data=data,
                                     headers={'Cache-Control': 'no-cache'})
    with opener.open(request, timeout=timeout) as response:
        return response.read(65536).decode('utf-8', errors='replace')


def identify_device(report):
    text = html.unescape(re.sub(r'<[^>]*>', '', report))
    if not re.search(r'(?m)^Device:\s*vent\s*$', text) or not re.search(r'(?m)^Meter:\s*VENTILATION\s*$', text):
        raise OtaError('The LAN address does not identify a Ventilation device')
    match = re.search(r'(?m)^MQTT unique device ID:\s*(vent-[0-9A-Fa-f]{12})\s*$', text)
    if not match:
        raise OtaError('Cannot confirm the hardware-specific Ventilation ID')
    recovery = bool(re.search(r'(?m)^Recovery mode:\s*YES\s*$', text))
    return match.group(1), recovery


def wait_for_recovery(ip, device_id, seconds, request, now, sleep):
    deadline = now() + seconds
    while now() < deadline:
        try:
            report = request(ip, '/network-debug', timeout=min(5, max(.1, deadline - now())))
            observed, recovery = identify_device(report)
            if observed != device_id:
                raise OtaError('A different device appeared at this IP; upload stopped')
            if recovery:
                page = request(ip, '/', timeout=min(5, max(.1, deadline - now())))
                if 'OTA-ONLY RECOVERY' in page:
                    return
        except (OSError, urllib.error.URLError):
            pass  # Reboot temporarily removes the HTTP listener.
        sleep(min(1, max(0, deadline - now())))
    raise OtaError('Recovery was not confirmed. No upload was sent; check the local Recovery page')


def perform_install(metadata, image, ip, host_ip, seconds, *, request=request_text,
                    runner=subprocess.run, now=time.monotonic, sleep=time.sleep, printer=print):
    device_id, recovery = identify_device(request(ip, '/network-debug'))
    printer('Target: ' + device_id + ' at ' + ip)
    if not recovery:
        printer('Entering OTA-only Recovery; the fan will remain OFF during installation.')
        try:
            request(ip, '/force-ota-recovery', {'confirm': 'ENTER'})
        except urllib.error.HTTPError as error:
            raise OtaError('Recovery request was rejected with HTTP ' + str(error.code)) from error
        except (OSError, urllib.error.URLError):
            # A lost response does not prove the POST failed. Poll once, never
            # repeat an uncertain state-changing request automatically.
            printer('Recovery response was interrupted; checking the device before upload.')
    wait_for_recovery(ip, device_id, seconds, request, now, sleep)
    # Upstream espota automatically prefers <image>.signed. A private temporary
    # copy guarantees it can upload only the exact bytes verified above.
    with tempfile.TemporaryDirectory(prefix='ventilation-ota-') as directory:
        verified = Path(directory) / metadata['filename']
        verified.write_bytes(image)
        command = [sys.executable, str(UPLOADER), '-i', ip, '-p', '8266',
                   '-f', str(verified), '-r']
        if host_ip:
            command += ['-I', host_ip]
        result = runner(command, check=False, timeout=300)
        if result.returncode:
            raise OtaError('LAN upload did not complete. Keep the device in Recovery and check the PC firewall/network')
    printer('Firmware upload completed. Waiting for a fresh firmware report...')
    deadline = now() + seconds
    while now() < deadline:
        try:
            status = json.loads(request(ip, '/mqtt-status', timeout=min(5, max(.1, deadline - now()))))
            if status.get('device') != device_id:
                raise OtaError('The post-upload device identity does not match')
            if status.get('firmware') == metadata['firmware']:
                printer(json.dumps(status, ensure_ascii=False))
                printer('Firmware ' + metadata['firmware'] + ' confirmed; MQTT connected: ' + str(status.get('mqtt_connected')))
                return status
        except (OSError, urllib.error.URLError, ValueError):
            pass
        sleep(min(1, max(0, deadline - now())))
    raise OtaError('Upload finished, but the new firmware was not confirmed. Open /mqtt-status; do not repeat the upload blindly')


def execute(args, **dependencies):
    metadata, image = verify_firmware(args.metadata, args.file)
    ip = private_ipv4(args.ip)
    host_ip = private_ipv4(args.host_ip) if args.host_ip else None
    printer = dependencies.get('printer', print)
    printer('Verified Ventilation ' + metadata['firmware'] + ': ' + str(len(image)) + ' bytes, SHA256 ' + metadata['sha256'])
    if not args.install:
        printer('Validation only; no device contacted. Add --install to enter Recovery and upload on the LAN.')
        return None
    return perform_install(metadata, image, ip, host_ip, args.wait_seconds, **dependencies)


def main(argv=None):
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--metadata', type=Path, default=PROJECT / 'artifacts/Ventilation_v2.01.json')
    parser.add_argument('--file', type=Path)
    parser.add_argument('--ip', default='192.168.1.81')
    parser.add_argument('--host-ip', help='PC LAN IPv4 address, if multiple network interfaces require it')
    parser.add_argument('--wait-seconds', type=int, choices=range(10, 181), default=60, metavar='10..180')
    parser.add_argument('--install', action='store_true', help='Explicitly enter Recovery and upload the verified firmware')
    args = parser.parse_args(argv)
    try:
        execute(args)
        return 0
    except (OtaError, OSError, ValueError, subprocess.TimeoutExpired) as error:
        print('OTA stopped: ' + str(error), file=sys.stderr)
        return 1


if __name__ == '__main__':
    raise SystemExit(main())
